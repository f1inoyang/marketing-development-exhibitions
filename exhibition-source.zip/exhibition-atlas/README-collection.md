# 官网监控与 GitHub 上线

GitHub 仓库的定时采集尚未启用。采集配置保存在源码包的 `.github/workflow-templates/collect.yml`；候选结果需人工审核后才能更新网站，不能视为全网实时收集。

## 已实现的采集边界

`scripts/collector.py` 使用 Python 3.9+ 标准库，读取 `data/sources.json` 中人工确认的主办方官网。它先检查 robots.txt，遵守访问间隔，设置超时和大小限制，仅通过 HTTPS 访问公共地址，拒绝跨来源跳转。遇到禁止访问、验证页、网络错误、无结构化信息时会记录真实状态。

此版本提取官网公开的 `application/ld+json` 中的 Event、@graph 和 itemListElement。它不会自动绕过访问限制，不会推测缺失日期，也不会将可访问的页面视为“展会已核验”。未提供结构化数据的站点需人工阅读或单独开发解析器。

这是一组已知官网的监控基础，不是全网检索引擎。“发现新展会”仍需接入合适的搜索/目录数据源并审核新主办方，才能加入监控。搜索服务授权、执行频率和预算尚未配置。

## 本地运行

从此网站目录运行：

```sh
python3 scripts/collector.py --dry-run
python3 -m unittest discover -s scripts -p 'test_*.py'
python3 scripts/collector.py --output-dir work/collection
```

`--dry-run` 只校验配置，不发起网络请求，也不写文件。真正执行后会在指定目录输出 `collection-status.json` 和 `review-queue.json`。脚本不会修改 `data/events.json` 或其他已发布记录。

2026年11月4日已对最初6个官方来源执行一次本地验证：6个页面返回 HTTP 200；MWC Barcelona 提取到2条待审核对象，其中1条为缺少日期的泛化首页对象，另1条包含2027年3月1—4日但缺少城市/国家字段；其余5个页面没有可解析的 Event JSON-LD，需人工处理。该次结果保留在开发验证目录，未当作新的已核验展会发布。配置校验与5项单元测试均通过。这证明基础抓取路径可用，不代表全网采集或定时服务已经上线。

候选中的 `verification: pending` 和 `reviewStatus: pending` 表示尚未审核；缺失信息列在 `missingFields`。同一内容重复采集会去重，已有队列的审核状态会保留。建议固定使用同一个本地输出目录积累队列。`success` 仅表示提取到候选，`manual_review` 表示网页可访问但不能自动提取，`blocked/error` 表示未完成采集。

## 审核与发布

1. 打开候选的 `sourceUrl`，确认展会年份、起止日期、城市、官网身份与主题，查看是否延期或取消。
2. 仅将已核验的记录写入正式展会数据，并附上来源链接和实际核验日期；缺失字段保持为空，不填估算值。
3. 发布后的正式日期优先于旧清单；保留来源批次和历史状态。参加企业、角色等信息需分别核验。
4. 本地核验前台、筛选和导出，再提交 GitHub。采集失败不能把旧数据标为刚更新。

## 后续启用 GitHub Pages

将网站目录内容作为仓库根目录。将 `pages.yml` 从 `.github/workflow-templates/` 移到 `.github/workflows/`，在仓库 Settings → Pages 将 Source 设为 GitHub Actions，然后执行工作流。部署脚本仅打包页面、前端资源和公开数据，不会打包审核队列。部署完成后还应检查公开链接实际可访问并与审核版一致。

每次部署执行 `python3 scripts/prepare_site.py --output-dir _site`，从正式 `events.json`、`verified-events.json`、采集状态及世界地图重新生成 `_site/data/bundle.js`；公开页面不包含已结束的原始清单。更新审核后的 JSON 即会进入下一次构建；不会复制过期的缓存 bundle。本地预览更新数据时可运行 `python3 scripts/build_bundle.py` 重新生成源目录中的 `data/bundle.js`。

`collect.yml` 是计划每日北京时间约 09:17 执行的候选工作流模板，尚未启用；GitHub 调度可能延迟。它把候选作为 Actions artifact 保存 30 天，不自动修改网站数据，也不发送外部消息。每次运行是独立审核包，跨运行合并可下载到本地用同一个队列目录管理。要形成前台“自动更新”，还需明确审核负责人及发布步骤；不能把计划任务模板等同于已上线服务。

## 实现参考

- [GitHub Pages 自定义部署工作流](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)
- [Schema.org Event](https://schema.org/Event)
- [robots.txt 规则说明](https://developers.google.com/crawling/docs/robots-txt/robots-txt-spec)





## 本次扩充

2026年11月5日，正式预览扩展为86场即将举办活动、35个国家/地区、83个去重官网地址。全部正式记录经过人工核验；扩充的监控地址尚未执行整批自动抓取，不把人工研究数量当作采集成功数。网站按开幕日期过滤，至2027年6月30日；历史下载入口已移除。
