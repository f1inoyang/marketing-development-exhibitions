'use strict';
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const escapeHTML=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ICONS={globe:'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18M5 7h14M5 17h14"/>',bookmark:'<path d="M6 4h12v17l-6-4-6 4z"/>',layers:'<path d="m12 3 9 5-9 5-9-5zm-9 9 9 5 9-5M3 16l9 5 9-5"/>',maximize:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',download:'<path d="M12 3v12m-4-4 4 4 4-4M4 16v5h16v-5"/>',sliders:'<path d="M4 6h16M4 12h16M4 18h16M8 3v6m8 0v6m-6 0v6"/>',search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',list:'<path d="M8 5h13M8 12h13M8 19h13M3 5h.1M3 12h.1M3 19h.1"/>',pin:'<path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0z"/><circle cx="12" cy="10" r="2"/>',check:'<path d="m5 12 4 4L19 6"/>',x:'<path d="m6 6 12 12M6 18 18 6"/>',bank:'<path d="m3 8 9-5 9 5zm0 13h18M5 10v8m7-8v8m7-8v8"/>',fintech:'<path d="M3 17 9 11l4 3 8-10m-6 0h6v6M3 21h18"/>',telecom:'<path d="M5 6a10 10 0 0 1 14 0M8 10a6 6 0 0 1 8 0m-5 4a2 2 0 0 1 2 0M12 17v4"/>',coin:'<circle cx="12" cy="12" r="9"/><path d="M9 7h5a3 3 0 0 1 0 5H9m0 0h5a3 3 0 0 1 0 5H9m1-12v14"/>',box:'<path d="m12 3 9 5v9l-9 5-9-5V8zm-9 5 9 5 9-5m-9 5v9M8 5l9 5"/>',shield:'<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6zm-4 9 3 3 5-6"/>',link:'<path d="m9 15 6-6m-7 4-2 2a3.5 3.5 0 1 0 5 5l3-3m-4-10 3-3a3.5 3.5 0 0 1 5 5l-2 2"/>',arrow:'<path d="M5 19 19 5M5 5h14v14"/>'};
const icon=name=>`<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name]||ICONS.globe}</svg>`;
const paintIcons=()=>$$('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon));
const REGIONS=[{id:'asia',name:'亚洲',en:'Asia',x:73,y:36},{id:'europe',name:'欧洲',en:'Europe',x:49,y:26},{id:'africa',name:'非洲',en:'Africa',x:51,y:59},{id:'north-america',name:'北美',en:'North America',x:21,y:32},{id:'south-america',name:'南美',en:'South America',x:30,y:70},{id:'oceania',name:'大洋洲',en:'Oceania',x:85,y:73}];
const TOPICS=[{id:'all',name:'全部主题',en:'All topics',icon:'grid'},{id:'fintech',name:'金融科技',en:'Fintech',icon:'fintech'},{id:'banking',name:'银行',en:'Banking',icon:'bank'},{id:'telecom',name:'电信',en:'Telecom',icon:'telecom'},{id:'digital-currency',name:'数字货币',en:'Digital Currency',icon:'coin'},{id:'packaging',name:'包装',en:'Packaging',icon:'box'},{id:'identity',name:'身份安全',en:'Identity & Security',icon:'shield'}];
const DATA=window.ATLAS_DATA||{events:[],meta:{}};
const events=DATA.events;
const SEASON={start:'2026-11-01',end:'2027-06-30'};
let language='zh';try{language=localStorage.getItem('atlas-language')==='en'?'en':'zh';}catch{}
const t=(zh,en)=>language==='en'?en:zh;
const txt=(e,key)=>language==='en'?(e[key+'En']||''):(e[key]||'');
const titleOf=e=>txt(e,'name')||e.nameEn||e.name;
const regionName=id=>{const r=REGIONS.find(r=>r.id===id);return r?t(r.name,r.en):id;};
const topicName=id=>{const r=TOPICS.find(r=>r.id===id);return r?t(r.name,r.en):id;};
const currentChinaDate=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
let today=currentChinaDate();
const isPast=e=>e.endDate<today;
const phase=e=>isPast(e)?'past':e.startDate<=today?'ongoing':'upcoming';
const phaseLabel=e=>({past:t('已结束','Ended'),ongoing:t('正在举办','In progress'),upcoming:t('即将举办','Upcoming')}[phase(e)]);
const official=events.filter(e=>e.verification==='official');
const lastVerified=official.map(e=>e.verifiedAt).filter(Boolean).sort().at(-1)||DATA.meta.importedAt;
const importedCount=events.filter(e=>e.verification==='imported').length;
const inSeason=e=>e.startDate>today&&e.startDate>=SEASON.start&&e.startDate<=SEASON.end;
let saved=new Set();try{saved=new Set(JSON.parse(localStorage.getItem('atlas-saved-v1')||'[]').filter(id=>events.some(e=>e.id===id)));}catch{}
const defaults={region:'all',topic:'all',q:'',period:'all',verification:'all',sort:'recommended',view:'grid',tab:'overview',scope:'season'};
const state={...defaults,limit:12};
let filtered=[],activeEvent=null,toastTimer;
const scopedEvents=()=>events.filter(inSeason);

function toast(message){$('#toast').textContent=message;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),2600);}
function safeURL(value){try{const u=new URL(value);return ['http:','https:'].includes(u.protocol)?u.href:'#';}catch{return '#';}}
function dates(e,long=false){
  const s=e.startDate.split('-'),end=e.endDate.split('-');
  if(language==='en'){
    const format=d=>new Intl.DateTimeFormat('en-GB',{day:'numeric',month:long?'long':'short',year:'numeric',timeZone:'UTC'}).format(new Date(d+'T12:00:00Z'));
    return format(e.startDate)+(e.startDate===e.endDate?'':' — '+format(e.endDate));
  }
  if(long)return e.startDate===e.endDate?`${s[0]}年${+s[1]}月${+s[2]}日`:`${s[0]}年${+s[1]}月${+s[2]}日 — ${s[0]!==end[0]?end[0]+'年':''}${+end[1]}月${+end[2]}日`;
  return `${s.join('.')}${e.startDate===e.endDate?'':` — ${s[0]===end[0]?(s[1]===end[1]?end[2]:end[1]+'.'+end[2]):end.join('.')}`}`;
}
function tagMarkup(e){return e.topics.map(key=>`<span class="tag ${escapeHTML(key)}">${topicName(key)}</span>`).join('');}
function updateURL(){const p=new URLSearchParams();for(const key of Object.keys(defaults))if(state[key]!==defaults[key])p.set(key,state[key]);if(language==='en')p.set('lang','en');if(activeEvent)p.set('event',activeEvent);history.replaceState(null,'',location.pathname+location.search+(p.size?'#'+p.toString():''));}
function readURL(){
  const p=new URLSearchParams(location.hash.slice(1));
  const allowed={region:['all',...REGIONS.map(r=>r.id)],topic:TOPICS.map(r=>r.id),period:['all','2026-11','2026-12','2027-01','2027-02','2027-03','2027-04','2027-05','2027-06'],verification:['all','official','imported'],sort:['recommended','date-asc','name'],view:['grid','list'],tab:['overview','saved'],scope:['season']};
  for(const key in allowed)if(allowed[key].includes(p.get(key)))state[key]=p.get(key);
  state.q=p.get('q')||'';if(['zh','en'].includes(p.get('lang')))language=p.get('lang');return p.get('event');
}
function applyLanguage(){
  document.documentElement.lang=language==='en'?'en':'zh-CN';
  document.title=t('Marketing Development — 全球市场拓展','Marketing Development — Global Market Expansion');
  $('meta[name="description"]').content=t('面向全球销售团队的展会情报地图，按区域和主题探索展会。','Global event intelligence for sales teams. Explore events by region and topic.');
  for(const [selector,zh,en,attribute] of window.ATLAS_STATIC_COPY||[]){const el=$(selector);if(!el)continue;if(attribute)el.setAttribute(attribute,t(zh,en));else el.innerHTML=t(zh,en);}
  $$('[data-language]').forEach(el=>{const selected=el.dataset.language===language;el.classList.toggle('active',selected);el.setAttribute('aria-pressed',selected);});
  $('#last-updated').textContent=t('数据核验 · ','Checked · ')+lastVerified.replaceAll('-','.');
  $('#world-map svg')?.setAttribute('aria-label',t('全球区域导航示意图','Schematic world region navigation map'));
  paintIcons();
}
function changeLanguage(lang){language=lang;try{localStorage.setItem('atlas-language',lang);}catch{}applyLanguage();render();if(activeEvent)renderDetail(events.find(e=>e.id===activeEvent));if($('#sources-dialog').open)renderSources();}
function selectRegion(id){state.region=id;state.tab='overview';state.limit=12;render();}
function saveEvent(id){
  if(saved.has(id))saved.delete(id);else saved.add(id);
  try{localStorage.setItem('atlas-saved-v1',JSON.stringify([...saved]));toast(saved.has(id)?t('已加入关注，保存在本机浏览器','Saved to this browser’s watchlist'):t('已取消关注','Removed from your watchlist'));}catch{toast(t('关注已更新；浏览器未允许持久保存','Watchlist updated for this session; browser storage is unavailable'));}
  render();if(activeEvent===id)renderDetail(events.find(e=>e.id===id));
}
function renderMap(){
  const pool=scopedEvents(),count=id=>pool.filter(e=>e.region===id).length,checked=id=>pool.filter(e=>e.region===id&&e.verification==='official').length;
  $('#region-nav').innerHTML=REGIONS.map(r=>`<button class="nav-item ${state.region===r.id&&state.tab==='overview'?'selected':''}" data-region="${r.id}" ${state.region===r.id?'aria-current="true"':''}><span class="region-dot"></span>${regionName(r.id)}<span class="nav-count">${count(r.id)}</span></button>`).join('');
  $('#map-pins').innerHTML=REGIONS.map(r=>`<button class="map-pin ${state.region===r.id?'selected':''}" style="left:${r.x}%;top:${r.y}%" data-region="${r.id}" aria-label="${escapeHTML(t(`${r.name}，${count(r.id)}场展会，${checked(r.id)}场已核验`,`${r.en}: ${count(r.id)} events, ${checked(r.id)} checked`))}" aria-pressed="${state.region===r.id}"><span>${regionName(r.id)}</span><span class="pin-count">${String(count(r.id)).padStart(2,'0')}</span>${checked(r.id)?`<span class="pin-new">+${checked(r.id)}</span>`:''}</button>`).join('');
  $$('[data-region]').forEach(el=>{el.onclick=()=>selectRegion(el.dataset.region);el.onmouseenter=()=>highlightMap(el.dataset.region,true);el.onmouseleave=()=>highlightMap(el.dataset.region,false);});
  $$('[data-continent]').forEach(el=>{el.classList.toggle('selected',el.dataset.continent===state.region);el.onclick=()=>selectRegion(el.dataset.continent);el.onmouseenter=()=>highlightMap(el.dataset.continent,true);el.onmouseleave=()=>highlightMap(el.dataset.continent,false);});
}
function highlightMap(region,on){$$('[data-continent]').filter(x=>x.dataset.continent===region).forEach(el=>el.classList.toggle('hovered',on));}
function getFiltered(){
  let rows=scopedEvents().filter(e=>(state.region==='all'||e.region===state.region)&&(state.topic==='all'||e.topics.includes(state.topic))&&(state.tab!=='saved'||saved.has(e.id))&&(state.period==='all'||e.startDate.slice(0,7)===state.period)&&(state.verification==='all'||e.verification===state.verification));
  const words=state.q.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  if(words.length)rows=rows.filter(e=>{const text=[e.name,e.nameEn,e.city,e.cityEn,e.country,e.countryEn,e.description,e.descriptionEn,...e.topics.flatMap(key=>{const topic=TOPICS.find(t=>t.id===key);return [topic?.name,topic?.en,key];})].join(' ').toLocaleLowerCase();return words.every(w=>text.includes(w));});
  rows.sort((a,b)=>{if(state.sort==='name')return titleOf(a).localeCompare(titleOf(b),language==='en'?'en':'zh-CN');if(state.sort==='date-asc')return a.startDate.localeCompare(b.startDate);if(isPast(a)!==isPast(b))return isPast(a)?1:-1;return isPast(a)?b.startDate.localeCompare(a.startDate):a.startDate.localeCompare(b.startDate);});return rows;
}
function card(e,i){
  const name=escapeHTML(titleOf(e)),city=escapeHTML(txt(e,'city')||t('城市待核实','City to be confirmed')),country=escapeHTML(txt(e,'country')),description=txt(e,'description');
  const verification=e.verification==='official'?t('官网核验 · ','Official check · ')+e.verifiedAt.replaceAll('-','.'):(e.dateConflict?t('原始清单 · 日期有差异','Source record · date conflict'):t('原始清单 · 待复核','Source record · not rechecked'));
  return `<article class="event-card ${isPast(e)?'past':''}" style="animation-delay:${Math.min(i,6)*30}ms"><div class="card-topline"><span class="card-region">${icon('globe')}${regionName(e.region)} <span>·</span> ${country}</span><button class="bookmark-button ${saved.has(e.id)?'saved':''}" data-save="${e.id}" aria-label="${saved.has(e.id)?t('取消关注','Unsave '):t('关注','Save ')}${name}" aria-pressed="${saved.has(e.id)}">${icon('bookmark')}</button></div><button class="card-main" data-event="${e.id}" aria-label="${t('查看展会详情：','View event details: ')}${name}"><div class="card-date">${dates(e)}${phase(e)!=='upcoming'?`<span class="date-state">${phaseLabel(e)}</span>`:''}</div><h3 class="card-title">${name}</h3>${language==='zh'?`<div class="card-english">${escapeHTML(e.nameEn)}</div>`:''}<div class="card-place">${icon('pin')}${city} · ${country}</div>${description?`<p class="card-description">${escapeHTML(description)}</p>`:''}</button><div class="card-tags">${tagMarkup(e)}</div><div class="card-footer"><span class="verification ${e.verification}">${icon(e.verification==='official'?'check':'layers')}${verification}</span><span class="card-arrow">↗</span></div></article>`;
}
function renderFeed(){
  const pool=scopedEvents().filter(e=>e.verification==='official'&&(state.region==='all'||e.region===state.region)).sort((a,b)=>a.startDate.localeCompare(b.startDate)).slice(0,3);
  $('#latest-feed').innerHTML=pool.map(e=>`<button class="feed-item" data-feed="${e.id}"><span class="feed-meta"><b>${regionName(e.region)} / ${topicName(e.topics[0])}</b><span>${t('已核验','Checked')}</span></span><div class="feed-name">${escapeHTML(titleOf(e))}</div><p class="feed-place">${e.startDate.replaceAll('-','.')} · ${escapeHTML(txt(e,'city'))}</p></button>`).join('');
  $$('[data-feed]').forEach(el=>el.onclick=()=>openEvent(el.dataset.feed));
}
function render(){
  filtered=getFiltered();renderMap();renderFeed();
  const pool=scopedEvents();$('#metric-total').textContent=pool.length;$('#metric-new').textContent=String(new Set(pool.map(e=>e.countryEn)).size).padStart(2,'0');$('#saved-count').textContent=pool.filter(e=>saved.has(e.id)).length;
  $$('[data-nav]').forEach(el=>el.classList.toggle('selected',el.dataset.nav===state.tab&&(state.tab==='saved'||state.region==='all')));
  const title=state.tab==='saved'?t('我的关注','Your watchlist'):state.region==='all'?t('探索全部展会','Explore the directory'):t(`${regionName(state.region)}展会`,`Events in ${regionName(state.region)}`);
  $('#crumb').textContent=state.tab==='saved'?t('我的关注','Watchlist'):state.region==='all'?t('全球概览','Global overview'):regionName(state.region);
  $('#section-title').innerHTML=`${title} <span id="result-count">${filtered.length}</span>`;
  $('#section-eyebrow').textContent=state.tab==='saved'?'YOUR PERSONAL WATCHLIST':state.region==='all'?'THE EXHIBITION DIRECTORY':`EXPLORE ${REGIONS.find(r=>r.id===state.region).en.toUpperCase()}`;
  const visibleTopics=TOPICS.filter(r=>r.id!=='identity'||state.scope==='all'||state.topic==='identity'||pool.some(e=>e.topics.includes('identity')));
  $('#topic-bar').innerHTML=visibleTopics.map(r=>`<button class="topic-button ${state.topic===r.id?'active':''}" data-topic="${r.id}" aria-pressed="${state.topic===r.id}">${icon(r.icon)}${topicName(r.id)}${language==='zh'&&r.id!=='all'&&r.id!=='identity'?`<small>${r.en}</small>`:''}</button>`).join('');
  $$('[data-topic]').forEach(el=>el.onclick=()=>{state.topic=el.dataset.topic;state.limit=12;render();});
  $('#search').value=state.q;$('#time-filter').value=state.period;$('#verification-filter').value=state.verification;$('#sort').value=state.sort;$('#scope-filter').value=state.scope;
  $('#event-grid').className='event-grid'+(state.view==='list'?' list':'');
  for(const view of ['grid','list']){$('#'+view+'-view').classList.toggle('active',state.view===view);$('#'+view+'-view').setAttribute('aria-pressed',state.view===view);}
  const count=status=>filtered.filter(e=>phase(e)===status).length;
  $('#result-summary').textContent=t(`共 ${filtered.length} 场即将举办展会 · 官网日期已核验`,`${filtered.length} upcoming event${filtered.length===1?'':'s'} · Official dates checked`);
  $('#filter-note').textContent=state.tab==='saved'?t('关注仅保存在当前浏览器','Watchlist stored in this browser'):t('开幕截至 2027.06.30 · 按举办地分区','Opening by 30 Jun 2027 · By host location');
  $('#event-grid').innerHTML=filtered.length?filtered.slice(0,state.limit).map(card).join(''):`<div class="empty-state">${icon(state.tab==='saved'?'bookmark':'search')}<h3>${state.tab==='saved'?t('把值得关注的展会，留在这里。','Keep your next connections here.'):t('这个筛选组合还没有已收录展会。','No recorded events match these filters.')}</h3><p>${state.tab==='saved'?t('点击展会卡片右上角的书签，即可保存到关注清单。','Select the bookmark on an event card to save it here.'):t('试试更换主题或区域。未收录不代表该地区没有展会。','Try another topic or region. No records does not mean no events exist.')}</p><button class="button secondary" id="empty-reset">${t('重置筛选','Reset filters')} →</button></div>`;
  $$('[data-event]').forEach(el=>el.onclick=()=>openEvent(el.dataset.event));$$('[data-save]').forEach(el=>el.onclick=()=>saveEvent(el.dataset.save));
  if($('#empty-reset'))$('#empty-reset').onclick=resetAll;
  if($('#empty-archive'))$('#empty-archive').onclick=()=>{resetAll();state.scope='all';render();};
  $('#load-more').hidden=filtered.length<=state.limit;const remaining=Math.max(0,filtered.length-state.limit);$('#load-more').textContent=t(`加载更多展会（剩余 ${remaining} 场） ↓`,`Load more events (${remaining} remaining) ↓`);
  paintIcons();updateURL();
}
function renderDetail(e){
  const past=isPast(e),name=escapeHTML(titleOf(e)),country=escapeHTML(txt(e,'country'));
  $('#event-detail').innerHTML=`<div class="detail-header"><div class="detail-topline"><span>${regionName(e.region)} / ${country} / ${t('展会详情','Event details')}</span><div class="detail-controls"><button class="detail-language" id="detail-language" aria-label="${t('Switch to English','切换为中文')}">${t('EN','中文')}</button><button class="icon-button" id="close-event" aria-label="${t('关闭展会详情','Close event details')}">${icon('x')}</button></div></div><p class="detail-date">${dates(e,true)}</p><h2 class="detail-title" id="dialog-title">${name}</h2>${language==='zh'?`<p class="detail-en">${escapeHTML(e.nameEn)}</p>`:''}<div class="detail-tags">${tagMarkup(e)}</div></div><div class="detail-body"><dl class="detail-facts"><div><dt>${t('举办城市','Host city')}</dt><dd>${escapeHTML(txt(e,'city')||t('城市待核实','City to be confirmed'))} · ${country}</dd></div><div><dt>${t('展会状态','Event status')}</dt><dd>${phaseLabel(e)}${past?t(' · 历史资料',' · Archive'):''}</dd></div><div><dt>${t('信息来源','Source')}</dt><dd>${e.verification==='official'?t('官网核验','Official website checked'):t('用户原始清单','Original source workbook')}</dd></div><div><dt>${e.verification==='official'?t('核验日期','Checked on'):t('原始资料日期','Source record date')}</dt><dd>${e.verification==='official'?e.verifiedAt:DATA.meta.sourceUpdatedAt}</dd></div></dl><section class="detail-section"><h3>${t('展会概览','Event overview')}</h3><p>${escapeHTML(txt(e,'description')||t('原始清单未提供展会简介。本条保留原始名称、日期、地点与官网链接；最新届次、议程和参展安排请查看主办方官网。','No overview was included in the source workbook. This record preserves its name, dates, location and website. Check the organizer for the latest edition, agenda and participation arrangements.'))}</p></section><section class="detail-section"><h3>${icon('shield')}${t('来源与核验说明','Source and verification')}</h3><p>${escapeHTML(txt(e,'sourceNote'))}</p><div class="source-box"><a href="${escapeHTML(safeURL(e.sourceUrl))}" target="_blank" rel="noopener noreferrer">${escapeHTML(e.sourceUrl)} ↗</a><small>${e.verification==='official'?t('核验范围：本届日期、举办城市及主题概述。','Checked: edition dates, host city and topic overview.'):t('该链接沿用原始 Excel，当前内容与可用性尚未重新核验。','This link comes from the original workbook; its current content and availability have not been rechecked.')}</small></div></section>${e.dateConflict?`<div class="conflict-note">${t('日期存在资料差异。本页采用 Excel 日期，海报所列日期不同；出行前请以主办方最新公告确认。','The source workbook and poster list different dates. This page uses the workbook dates. Confirm with the organizer before making travel arrangements.')}</div>`:''}<div class="detail-actions"><a class="button primary" href="${escapeHTML(safeURL(e.sourceUrl))}" target="_blank" rel="noopener noreferrer">${t('前往主办方官网','Visit organizer website')} ${icon('arrow')}</a><button class="button secondary" id="detail-save">${icon('bookmark')}${saved.has(e.id)?t('已关注','Saved'):t('加入关注','Save event')}</button><button class="button secondary" id="detail-export" aria-label="${t('下载本场展会','Download this event')}">${icon('download')}</button></div><p class="detail-footnote">${past?t('本场展会已结束。不可据此推定下一届举办日期。','This edition has ended. These dates do not confirm the next edition.'):t('参会资格、展位余量与参会企业名单不在本次核验范围内。','Participation eligibility, booth availability and attendee lists were not verified.')}</p></div>`;
  $('#event-dialog').setAttribute('aria-labelledby','dialog-title');$('#close-event').onclick=()=>$('#event-dialog').close();$('#detail-save').onclick=()=>saveEvent(e.id);$('#detail-export').onclick=()=>exportCSV([e]);$('#detail-language').onclick=()=>changeLanguage(language==='zh'?'en':'zh');
}
function openEvent(id){const e=scopedEvents().find(e=>e.id===id);if(!e)return;activeEvent=id;renderDetail(e);if(!$('#event-dialog').open)$('#event-dialog').showModal();$('#event-dialog').scrollTop=0;updateURL();}
function resetAll(){const scope=state.scope;Object.assign(state,defaults,{scope,limit:12});render();}
function download(content,type,filename){const blob=new Blob([content],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);$('#download-menu').hidden=true;$('#download-button').setAttribute('aria-expanded','false');}
function csvCell(v){let s=String(v??'');if(/^[\s]*[=+@-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}
function exportCSV(rows){
  if(!rows.length){toast(t('当前筛选没有可下载的展会','No events to download for these filters'));return;}
  const header=t(['展会名称','英文名称','大区','国家','城市','开始日期','结束日期','主题','当前状态','数据来源','核验日期','原始资料日期','官网链接','简介','核验说明'],['Event name','Official event name','Region','Country','City','Start date','End date','Topics','Status','Source type','Checked on','Source record date','Official website','Overview','Verification notes']);
  const body=rows.map(e=>[titleOf(e),e.nameEn,regionName(e.region),txt(e,'country'),txt(e,'city'),e.startDate,e.endDate,e.topics.map(topicName).join(' / '),phaseLabel(e),e.verification==='official'?t('官网核验','Official website checked'):t('原始清单','Original workbook'),e.verifiedAt||'',e.verification==='imported'?DATA.meta.sourceUpdatedAt:'',e.sourceUrl,txt(e,'description'),txt(e,'sourceNote')]);
  download('\uFEFF'+[header,...body].map(r=>r.map(csvCell).join(',')).join('\r\n'),'text/csv;charset=utf-8',t(`ATLAS_展会清单_${rows.length}场_${today}.csv`,`ATLAS_Events_${rows.length}_${today}_EN.csv`));toast(t(`已下载 ${rows.length} 场展会，含官网和核验说明`,`Downloaded ${rows.length} event${rows.length===1?'':'s'} with sources and verification notes`));
}
function renderSources(){
  const pool=scopedEvents(),status=DATA.collectionStatus||{},countries=new Set(pool.map(e=>e.countryEn)).size;
  $('#sources-content').innerHTML=`<div class="source-stats"><div class="source-stat"><strong>${pool.length}</strong>${t('即将举办展会','Upcoming events')}</div><div class="source-stat"><strong>${countries}</strong>${t('国家 / 地区','Countries / territories')}</div><div class="source-stat"><strong class="small">${status.scheduled?t('已配置','Configured'):t('待上线','Not active')}</strong>${t('候选采集计划','Candidate collection')}</div></div><div class="source-explanation"><strong>${t('当前收集范围：即日起至2027年6月30日。','Current window: upcoming events through 30 June 2027.')}</strong>${t('只展示尚未开始、开幕日期不晚于2027年6月30日的活动，按北京时间判断；跨月活动保留完整结束日。已开始、已结束及日期未公布的活动不计入。覆盖六大区及五大主题，另附身份安全相关活动。','Only events that have not started and open by 30 June 2027 are shown, using the date in Asia/Shanghai. Full end dates are retained for cross-month events. Started, ended and undated events are excluded. Coverage spans six regions, five core topics and related identity and security events.')}</div><div class="source-explanation">${t(`每条记录均附官网链接与核验说明。最近核验日期：${lastVerified}。同一展会的同期分论坛不重复计数；独立城市或届次分别收录。此清单是已核验的公开信息汇集，不代表全球展会的穷尽目录。`,`Each record includes an official link and verification notes. Latest check: ${lastVerified}. Co-located subforums are not counted separately; distinct cities or editions are separate records. This is a collection of verified public information, not an exhaustive global census.`)}</div><div class="source-explanation"><strong>${status.scheduled?t('已配置定时监控官网，候选须人工审核后才更新网站。','Scheduled monitoring is configured; candidates require human review before publication.'):t('当前为人工核验预览，定时采集尚未启用。','This is a manually verified preview; scheduled collection is not active.')}</strong>${t('采集限于已配置的官网，不是全网实时爬取。地图「+」表示官网核验记录；活动安排可能变更。','Collection covers configured official sources, not the whole web in real time. Map “+” counts indicate checked records; event arrangements may change.')}</div><div class="source-list">${pool.map(e=>`<div class="source-row"><a href="${escapeHTML(safeURL(e.sourceUrl))}" target="_blank" rel="noopener noreferrer">${escapeHTML(titleOf(e))} ↗<br><small>${escapeHTML(new URL(e.sourceUrl).hostname)}</small></a><span class="status">${t('官网页面核验','Official page checked')}</span></div>`).join('')}</div><div class="source-explanation" style="border:0;padding-bottom:0"><strong>${t('分区、语言与下载','Regions, languages and downloads')}</strong><br>${t('按举办地分区，墨西哥归北美、澳大利亚归大洋洲。中英文切换保留筛选及关注；下载包含当前筛选的全部结果及官网来源，不受页面显示条数限制。关注仅保存在当前浏览器。','Grouped by host location: Mexico is in North America and Australia in Oceania. Language switching preserves filters and saved events. Downloads include all filtered results and official sources, including results not yet loaded on screen. Your watchlist is stored in this browser.')}</div>`;
}
function openSources(){renderSources();$('#sources-dialog').showModal();}
function refreshDate(){
  const next=currentChinaDate();if(next===today)return;
  today=next;
  if(activeEvent&&!scopedEvents().some(e=>e.id===activeEvent))$('#event-dialog').close();
  render();if($('#sources-dialog').open)renderSources();
}

$('#world-map').innerHTML=DATA.worldMap||'';
const initialEvent=readURL();applyLanguage();
$$('[data-language]').forEach(el=>el.onclick=()=>changeLanguage(el.dataset.language));
$('#search').oninput=e=>{state.q=e.target.value;state.limit=12;render();};
for(const [id,key] of [['time-filter','period'],['verification-filter','verification'],['sort','sort'],['scope-filter','scope']])$('#'+id).onchange=e=>{state[key]=e.target.value;state.limit=12;render();};
$('#grid-view').onclick=()=>{state.view='grid';render();};$('#list-view').onclick=()=>{state.view='list';render();};
$('#reset-filters').onclick=()=>{Object.assign(state,{topic:'all',q:'',period:'all',verification:'all',sort:'recommended',limit:12});render();};
$('#reset-map').onclick=()=>selectRegion('all');$('#load-more').onclick=()=>{state.limit+=12;render();};
$$('[data-nav]').forEach(el=>el.onclick=()=>{resetAll();state.tab=el.dataset.nav;render();if(state.tab==='saved')$('#events').scrollIntoView({behavior:'smooth'});});
$('.brand').onclick=e=>{e.preventDefault();resetAll();window.scrollTo({top:0,behavior:'smooth'});};
$('#verified-filter').onclick=()=>{Object.assign(state,{region:'all',topic:'all',q:'',period:'all',verification:'official',tab:'overview',limit:12});render();$('#events').scrollIntoView({behavior:'smooth'});};
$('#download-button').onclick=()=>{const open=$('#download-menu').hidden;$('#download-menu').hidden=!open;$('#download-button').setAttribute('aria-expanded',open);};
$('#export-csv').onclick=()=>exportCSV(filtered);
$('#export-json').onclick=()=>{if(!filtered.length){toast(t('当前筛选没有可下载的展会','No events to download for these filters'));return;}download(JSON.stringify({exportedAt:today,language,meta:DATA.meta,filters:{...state},events:filtered},null,2),'application/json',`ATLAS_Events_${filtered.length}_${today}_${language.toUpperCase()}.json`);toast(t(`已下载 ${filtered.length} 场展会的双语完整数据`,`Downloaded ${filtered.length} complete bilingual event records`));};
$('#sources-button').onclick=openSources;$('#footer-sources').onclick=openSources;
$$('[data-close]').forEach(el=>el.onclick=()=>$('#'+el.dataset.close).close());
$('#event-dialog').addEventListener('close',()=>{activeEvent=null;updateURL();});
$$('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const rect=d.getBoundingClientRect();if(e.clientX<rect.left||e.clientX>rect.right||e.clientY<rect.top||e.clientY>rect.bottom)d.close();}}));
document.addEventListener('click',e=>{if(!e.target.closest('.download-wrap')){$('#download-menu').hidden=true;$('#download-button').setAttribute('aria-expanded','false');}});
document.addEventListener('keydown',e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#search').focus();$('#search').scrollIntoView({block:'center',behavior:'smooth'});}if(e.key==='Escape'){$('#download-menu').hidden=true;$('#download-button').setAttribute('aria-expanded','false');}});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshDate();});
setInterval(refreshDate,60000);
render();if(initialEvent)openEvent(initialEvent);
