#!/usr/bin/env python3
"""Prepare public static assets without publishing collection scripts/review queue."""
import argparse
from pathlib import Path
import shutil
from build_bundle import build_bundle

root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--output-dir", type=Path, default=root / "_site")
args = parser.parse_args()
destination = args.output_dir.resolve()
if destination == root:
    parser.error("Output directory must be separate from the website source directory")
destination.mkdir(parents=True, exist_ok=True)
# Rebuild from current reviewed JSON every time; never copy a stale source bundle.
event_count = build_bundle(root, destination / "data" / "bundle.js")
for item in root.iterdir():
    if item.is_file() and item.suffix in {".html", ".css", ".js", ".svg", ".png", ".ico", ".webmanifest"}:
        shutil.copy2(item, destination / item.name)
for name in ("assets", "downloads"):
    source = root / name
    if source.is_dir():
        shutil.copytree(source, destination / name, dirs_exist_ok=True)
(destination / "data").mkdir(exist_ok=True)
for name in ("events.json", "verified-events.json", "sources.json", "collection-status.json"):
    source = root / "data" / name
    if source.is_file():
        shutil.copy2(source, destination / "data" / name)
(destination / ".nojekyll").touch()
print("Prepared public site in", destination, "with", event_count, "upcoming events and the world map")
