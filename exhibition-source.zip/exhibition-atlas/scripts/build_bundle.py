#!/usr/bin/env python3
"""Build the offline-compatible browser data bundle from reviewed source files."""
import argparse
import json
from pathlib import Path


def build_bundle(root, output):
    data_dir = root / "data"
    imported = json.loads((data_dir / "events.json").read_text(encoding="utf-8"))
    verified = json.loads((data_dir / "verified-events.json").read_text(encoding="utf-8"))
    collection = json.loads((data_dir / "collection-status.json").read_text(encoding="utf-8"))
    world_map = (root / "assets" / "world.svg").read_text(encoding="utf-8")
    events = imported["events"] + verified["events"]
    ids = [event["id"] for event in events]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate event IDs in reviewed data; resolve before publishing")
    if "<svg" not in world_map:
        raise ValueError("World map asset is not an SVG document")
    bundle = {"meta": imported["meta"], "events": events, "worldMap": world_map, "collectionStatus": collection}
    serialized = json.dumps(bundle, ensure_ascii=False, separators=(",", ":"))
    serialized = serialized.replace("<", "\\u003c").replace(">", "\\u003e").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("window.ATLAS_DATA=" + serialized + ";\n", encoding="utf-8")
    return len(events)


def main():
    root = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=root / "data" / "bundle.js")
    args = parser.parse_args()
    count = build_bundle(root, args.output)
    print("Built browser data bundle:", args.output, "(" + str(count) + " events)")


if __name__ == "__main__":
    main()
